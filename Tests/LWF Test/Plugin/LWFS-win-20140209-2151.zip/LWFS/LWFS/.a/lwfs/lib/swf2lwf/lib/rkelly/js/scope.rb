module RKelly
  module JS
    class Scope < Base
    end
  end
end
