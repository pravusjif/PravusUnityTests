module RKelly
  module Nodes
    class StrictEqualNode < BinaryNode
    end
  end
end
