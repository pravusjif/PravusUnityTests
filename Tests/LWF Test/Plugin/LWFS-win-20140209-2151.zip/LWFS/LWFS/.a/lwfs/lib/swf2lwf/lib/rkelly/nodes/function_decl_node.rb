module RKelly
  module Nodes
    class FunctionDeclNode < FunctionExprNode
    end
  end
end
