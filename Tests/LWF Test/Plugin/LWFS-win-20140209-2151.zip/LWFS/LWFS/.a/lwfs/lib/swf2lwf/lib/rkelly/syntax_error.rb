module RKelly
  class SyntaxError < ::SyntaxError
  end
end
