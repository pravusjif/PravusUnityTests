module RKelly
  VERSION = '1.0.6'
end
