module RKelly
  module Nodes
    class NotStrictEqualNode < BinaryNode
    end
  end
end
