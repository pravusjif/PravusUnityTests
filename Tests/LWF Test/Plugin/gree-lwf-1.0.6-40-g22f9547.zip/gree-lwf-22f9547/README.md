# LWF - Lightweight SWF
![LWF - Lightweight SWF ](http://gree.github.com/lwf-demo/images/LWF-logo.png)

**LWF is a technology to let you have animated 2D character animations and 2D user interfaces easily.**

**Read more http://gree.github.com/lwf/**
