(function() {

var RangeCoder = {};
var LZ = {};
var LZMA = {};

