
	global["LWF"].LZMA = Util;

}).call(this);
