NAudio is an open source .NET audio library written by Mark Heath (mark.heath@gmail.com)
For more information, visit http://naudio.codeplex.com

THANKS
======
The following list includes some of the people who have contributed in various ways to NAudio, such as code contributions,
bug fixes, documentation, helping out on the forums and even donations. I haven't finished compiling this list yet, so
if your name should be on it but isn't please let me know and I will include it. Also, some people I only know by their forum
id, so if you want me to put your full name here, please also get in touch.

in alphabetical order:
Alexandre Mutel
AmandaTarafaMas
Brandon Hansen (kg6ypi)
balistof
biermeester
ChunkWare Music Software
CKing
DaMacc
eejake52
Giawa
Hfuy
Idael Cardaso 
jbaker8935
jonahoffmann
Lustild
ManuN
Michael Feld 
Michael J
Nikolaos Georgiou
Pygmy
Ray Molenkamp
Robert Bristow-Johnson
Scott Fleischman 
Sirish Bajpai
Steve Underwood
Ted Murphy
Thefiloe
Tiny Simple Tools
Tobias Fleming
Tony Cabello
topher3683
Ville Koskinen
Wyatt Rice
Yuval Naveh
Zsb
