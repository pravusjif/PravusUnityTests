﻿using UnityEngine;
using System.Collections;

//	[SyncScale]
public class Obstacle : MonoBehaviour {

	// Use this for initialization
	void Start ()
	{
	}	
}
